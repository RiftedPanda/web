<?php
	include 'header.php';
?>

	<form action="search.php"  method="POST">
	<div class="search-box">
		<input id="search-txt" class="search-txt" type="text" name="search" placeholder="Type to search">
		<button type="submit" name="submit-search" class="search-btn">
				<i class="fas fa-search"></i>
		</button>
		</div>
	</form>

	<h1>Front Page</h1>
	<h2>All Articles</h2>

	<div class="user-container">
		<?php
			$sql = "SELECT * FROM users";
			$result = mysqli_query($conn, $sql);
			$queryResults = mysqli_num_rows($result);

			if ($queryResults > 0) {
			 	while ($row = mysqli_fetch_assoc($result)) {
		 			$nick = $row['u_nickname'];
		 			$img = $row['u_image'];
		 			$text = $row['u_text'];
		 			$name = $row['u_name'];
		 			$datetime = $row['u_date'];
			 	}
			 } else {
			 	# code...
			 }
			  
		?>
	</div>

</body>
</html>